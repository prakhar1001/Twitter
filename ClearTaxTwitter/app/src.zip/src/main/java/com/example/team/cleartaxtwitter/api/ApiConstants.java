package com.example.team.cleartaxtwitter.api;

/**
 * Created by Prakhar on 21-Sep-16.
 */
public class ApiConstants {

    public final static String CONSUMER_KEY = "Xr9bpMNpHaX8RB0SBbpcwcGYE"; // HIDDEN, please obtain your one on twitter developers

    public	final static String CONSUMER_SECRET = "H0a42GiiXdXW5HfUba10bOfUlIYlhXpCk3DtiM8YcHzHqK8MMs";  // HIDDEN, please obtain your one on twitter developers

    public final static String TWITTER_SEARCH_URL = "https://api.twitter.com";

    public static final String BEARER_TOKEN_CREDENTIALS = CONSUMER_KEY + ":" + CONSUMER_SECRET;

    public final static String TWITTER_HASHTAG_SEARCH_CODE = "/1.1/search/tweets.json";

}
