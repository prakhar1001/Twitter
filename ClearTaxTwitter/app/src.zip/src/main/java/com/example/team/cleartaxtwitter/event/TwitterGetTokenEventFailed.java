package com.example.team.cleartaxtwitter.event;

/**
 * Created by Prakhar on 21-Sep-16.
 */
public class TwitterGetTokenEventFailed {
}
