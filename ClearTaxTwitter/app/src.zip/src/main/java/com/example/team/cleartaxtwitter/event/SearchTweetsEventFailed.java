package com.example.team.cleartaxtwitter.event;

/**
 * Created by Prakhar on 21-Sep-16.
 */
public class SearchTweetsEventFailed {

    // for now just show error page
    // TODO add error codes

}
